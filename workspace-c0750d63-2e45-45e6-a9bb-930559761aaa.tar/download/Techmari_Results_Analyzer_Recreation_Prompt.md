# Techmari Results Analyzer - Complete Recreation Prompt

## Project Overview

Create a Next.js 15 web application called **"Techmari Results Analyzer"** - a comprehensive soccer historical data analysis and prediction platform. The app analyzes historical match results from football-data.co.uk and provides a Monte Carlo simulation-based prediction engine.

---

## Data Sources

### Primary Data Source
- **URL**: https://www.football-data.co.uk/data.php
- **Format**: CSV files for each league/season
- **Leagues (25 total)**:
  - England: Premier League (E0), Championship (E1), League 1 (E2), League 2 (E3)
  - Scotland: Premiership (SC0), Championship (SC1)
  - Germany: Bundesliga (D1), Bundesliga 2 (D2)
  - Italy: Serie A (I1), Serie B (I2)
  - Spain: La Liga (SP1), La Liga 2 (SP2)
  - France: Ligue 1 (F1), Ligue 2 (F2)
  - Netherlands: Eredivisie (N1)
  - Belgium: First Division A (B1)
  - Portugal: Primeira Liga (P1)
  - Turkey: Super Lig (T1)
  - Greece: Super League (G1)
  - Austria: Bundesliga (A1)
  - Poland: Ekstraklasa (PO1)
  - Denmark: Superligaen (DN1)
  - Norway: Eliteserien (NO1)
  - Sweden: Allsvenskan (SE1)
  - Switzerland: Super League (SW1)
  - Argentina: Primera Division (AR1)
  - Brazil: Serie A (BR1)

- **Seasons**: Current season plus 7 previous seasons (8 seasons total)
- **CSV Structure**: Contains columns like:
  - `Div` - League division
  - `Date` - Match date (DD/MM/YYYY)
  - `HomeTeam`, `AwayTeam` - Team names
  - `FTHG`, `FTAG` - Full time home/away goals
  - `FTR` - Full time result (H/D/A)
  - `HTHG`, `HTAG` - Half time home/away goals
  - `HTR` - Half time result (H/D/A)
  - `B365H`, `B365D`, `B365A` - Bet365 odds
  - `BbAvH`, `BbAvD`, `BbAvA` - Average bookmaker odds
  - And many more betting odds columns

---

## Application Structure

### File Structure
```
src/
├── app/
│   ├── layout.tsx          # Root layout with metadata
│   ├── page.tsx            # Main application with all tabs
│   ├── globals.css         # Tailwind imports
│   └── api/
│       └── soccer/
│           ├── data/
│           │   └── route.ts    # Fetches and processes CSV data
│           ├── predict/
│           │   └── route.ts    # Monte Carlo prediction engine
│           └── patterns/
│               └── route.ts    # Pattern identification API
```

---

## API Routes Specifications

### 1. `/api/soccer/data` Route

**Purpose**: Fetch and process historical match data from football-data.co.uk

**Implementation Details**:
- Build CSV URLs dynamically: `https://www.football-data.co.uk/mmz4281/{seasonCode}/{league}.csv`
- Season codes: Current season = "2425", previous = "2324", "2223", "2122", "2021", "1920", "1819", "1718"
- Fetch all CSVs concurrently using Promise.all
- Parse CSV data, normalize team names, handle missing values
- Calculate league averages for home goals, away goals, total goals
- Return structured JSON with:
  - `matches`: Array of all matches with normalized data
  - `leagues`: Object with league info and team lists
  - `seasons`: Available seasons
  - `lastUpdated`: Timestamp

**Caching**: Implement 10-minute in-memory cache to avoid rate limiting

**Response Structure**:
```typescript
interface SoccerData {
  matches: Match[];
  leagues: Record<string, { name: string; teams: string[] }>;
  seasons: string[];
  lastUpdated: string;
}

interface Match {
  league: string;
  leagueName: string;
  season: string;
  date: string;
  homeTeam: string;
  awayTeam: string;
  fthg: number;  // Full time home goals
  ftag: number;  // Full time away goals
  ftr: string;   // Full time result (H/D/A)
  hthg: number;  // Half time home goals
  htag: number;  // Half time away goals
  htr: string;   // Half time result
  odds: {
    home: number | null;
    draw: number | null;
    away: number | null;
  };
}
```

### 2. `/api/soccer/predict` Route

**Purpose**: Generate match predictions using Monte Carlo simulation and Poisson distribution

**Query Parameters**:
- `homeTeam`: Home team name
- `awayTeam`: Away team name
- `league`: League code (optional, for context)

**Algorithm**:

1. **Calculate Team Statistics** from historical matches:
   ```
   // Home team stats (when playing at home)
   homeGoalsScored = average goals scored by home team at home
   homeGoalsConceded = average goals conceded by home team at home
   homeMatches = number of home matches
   
   // Away team stats (when playing away)
   awayGoalsScored = average goals scored by away team away
   awayGoalsConceded = average goals conceded by away team away
   awayMatches = number of away matches
   
   // League averages
   leagueAvgHomeGoals = all home goals / all matches
   leagueAvgAwayGoals = all away goals / all matches
   ```

2. **Calculate Attack/Defense Strength**:
   ```
   homeAttackStrength = (homeTeamHomeAvg / leagueAvgHomeGoals)
   homeDefenseStrength = (homeTeamHomeConceded / leagueAvgAwayGoals)
   awayAttackStrength = (awayTeamAwayAvg / leagueAvgAwayGoals)
   awayDefenseStrength = (awayTeamAwayConceded / leagueAvgHomeGoals)
   
   // Clamp values to reasonable range (0.3 to 2.5)
   ```

3. **Home Advantage Factor**: 1.15 (configurable)

4. **Calculate Expected Goals (xG) using Poisson lambda**:
   ```
   lambda_home = homeAttack * awayDefense * leagueAvgHomeGoals * homeAdvantage
   lambda_away = awayAttack * homeDefense * leagueAvgAwayGoals
   ```

5. **Monte Carlo Simulation** (100,000 iterations):
   ```
   FOR each iteration:
     homeGoals = Poisson(lambda_home)
     awayGoals = Poisson(lambda_away)
     
     IF homeGoals > awayGoals: homeWins++
     IF homeGoals == awayGoals: draws++
     IF awayGoals > homeGoals: awayWins++
     
     IF homeGoals + awayGoals > 2.5: over25++
     IF homeGoals + awayGoals > 3.5: over35++
     IF homeGoals > 0 AND awayGoals > 0: btts++
     
     // Track score frequencies
     scores[homeGoals + "-" + awayGoals]++
   ```

6. **Calculate Probabilities**:
   - Home/Draw/Away percentages
   - Over 2.5 / Under 2.5
   - Over 3.5 / Under 3.5
   - BTTS Yes/No
   - Score matrix with top 20 most likely scores

7. **Confidence Level**:
   ```
   maxProb = max(homeWin%, draw%, awayWin%)
   IF maxProb >= 55: "High"
   ELSE IF maxProb >= 45: "Medium"
   ELSE IF maxProb >= 38: "Low"
   ELSE: "Very Low"
   ```

**Response Structure**:
```typescript
interface PredictionResponse {
  homeTeam: string;
  awayTeam: string;
  league: string;
  expectedGoals: {
    home: number;
    away: number;
    total: number;
  };
  probabilities: {
    homeWin: number;
    draw: number;
    awayWin: number;
    over25: number;
    under25: number;
    over35: number;
    under35: number;
    bttsYes: number;
    bttsNo: number;
  };
  confidence: "Very Low" | "Low" | "Medium" | "High";
  scoreMatrix: Array<{
    score: string;
    homeGoals: number;
    awayGoals: number;
    probability: number;
    count: number;
  }>;
  teamStats: {
    home: TeamStats;
    away: TeamStats;
  };
  h2hStats: H2HStats;
  patterns: MatchPatterns;
}

interface TeamStats {
  teamName: string;
  homeMatches: number;
  awayMatches: number;
  totalMatches: number;
  avgGoalsScoredHome: number;
  avgGoalsConcededHome: number;
  avgGoalsScoredAway: number;
  avgGoalsConcededAway: number;
  attackStrength: number;
  defenseStrength: number;
  homeWinRate: number;
  drawRate: number;
  awayWinRate: number;
  bttsRate: number;
  over25Rate: number;
}

interface H2HStats {
  totalMatches: number;
  homeWins: number;
  draws: number;
  awayWins: number;
  avgTotalGoals: number;
  bttsPercentage: number;
  recentMatches: Match[];
}
```

### 3. `/api/soccer/patterns` Route

**Purpose**: Identify patterns in team and league data

**Query Parameters**:
- `team`: Team name (optional)
- `league`: League code (optional)

**Pattern Types**:
1. **BTTS Patterns**:
   - Both halves BTTS percentage
   - First half only BTTS
   - Second half only BTTS
   - Neither half BTTS

2. **Goal Timing Analysis**:
   - First half goals percentage
   - Second half goals percentage
   - Late goals (75+ min) percentage

3. **HT/FT Transitions**:
   - HT Home Win → FT Home Win
   - HT Draw → FT Draw
   - HT Away Win → FT Away Win
   - Comeback rates

4. **Match Outcome Patterns**:
   - High-scoring matches (4+ goals)
   - Low-scoring matches (0-1 goals)
   - Clean sheets
   - Failed to score

---

## User Interface

### Layout & Styling
- Use **Tailwind CSS** for all styling
- Dark theme with professional appearance
- Responsive design (mobile-first)
- Clean, data-focused UI

### Color Scheme
- Primary background: `bg-gray-900`
- Secondary background: `bg-gray-800`
- Cards: `bg-gray-800/50`
- Text: `text-white`, `text-gray-400`
- Accent colors: `bg-blue-600`, `bg-green-600`, `bg-red-600`
- Probability bars: Gradient from green (high) to red (low)

### Header
```
┌─────────────────────────────────────────────────────────┐
│  ⚽ Techmari Results Analyzer                           │
│  Historical match analysis with Monte Carlo predictions │
└─────────────────────────────────────────────────────────┘
```

### Tab Navigation
Three tabs with icons:
1. 📊 League Overview
2. ⚔️ Head to Head
3. 🔮 Predictions

---

## Tab 1: League Overview

### Controls Section
```
┌─────────────────────────────────────────────────────────┐
│  [League Dropdown ▼]  [Season Dropdown ▼]  [🔄 Refresh] │
└─────────────────────────────────────────────────────────┘
```

### Statistics Cards Row
```
┌──────────────┐ ┌──────────────┐ ┌──────────────┐ ┌──────────────┐
│ Total Matches│ │ Avg Home Goals│ │ Avg Away Goals│ │   BTTS %     │
│     380      │ │     1.65     │ │     1.25     │ │    52.3%     │
└──────────────┘ └──────────────┘ └──────────────┘ └──────────────┘
```

### Team Statistics Table
Columns:
- Position
- Team Name
- Played
- Won / Draw / Lost
- Goals For / Against / Diff
- Points
- Win Rate
- BTTS Rate
- Over 2.5 Rate
- Avg Goals

### Team Form Display
- Last 5 matches as colored circles: W (green), D (yellow), L (red)
- Visual representation of recent performance

### League Trends Section
- Home win percentage
- Draw percentage
- Away win percentage
- Goal distribution chart
- BTTS analysis

---

## Tab 2: Head to Head

### Team Selection
```
┌─────────────────────────────────────────────────────────┐
│  [Team 1 Dropdown ▼]         vs         [Team 2 ▼]     │
│                     [Compare Teams]                     │
└─────────────────────────────────────────────────────────┘
```

### Comparison Display
- Side-by-side team statistics
- Visual comparison bars
- H2H history table
- Recent encounters

### Statistics Compared
- Overall win rate
- Home performance
- Away performance
- Goal averages
- BTTS percentage in meetings
- Over 2.5 percentage in meetings

### H2H History Table
Columns:
- Date
- Home Team
- Score
- Away Team
- Result (W/D/L for Team 1)
- Half Time Score

---

## Tab 3: Predictions

### Team Selection Controls
```
┌─────────────────────────────────────────────────────────┐
│  [League Dropdown ▼]                                    │
│  [Home Team Dropdown ▼]    vs    [Away Team Dropdown ▼]│
│                  [🔮 Generate Prediction]               │
└─────────────────────────────────────────────────────────┘
```

### Confidence Banner
Large banner showing confidence level with color coding:
- High (55%+): Green background
- Medium (45-54%): Yellow background
- Low (38-44%): Orange background
- Very Low (<38%): Red background

### Main Probability Cards
```
┌─────────────┐  ┌─────────────┐  ┌─────────────┐
│   HOME WIN  │  │    DRAW     │  │  AWAY WIN   │
│    45.2%    │  │    25.1%    │  │    29.7%    │
│   ▓▓▓▓▓░░   │  │   ▓▓░░░░░   │  │   ▓▓░░░░░   │
└─────────────┘  └─────────────┘  └─────────────┘
```

### Expected Goals Display
```
┌───────────────────────────────────────────┐
│  Expected Goals                           │
│  Home: 1.45  │  Away: 1.12  │  Total: 2.57│
└───────────────────────────────────────────┘
```

### Market Probabilities
```
┌─────────────── Market Probabilities ───────────────┐
│  Over 2.5 Goals:  52.3%  ████████████░░░░  Under: 47.7%
│  Over 3.5 Goals:  31.2%  ███████░░░░░░░░░  Under: 68.8%
│  BTTS Yes:        48.9%  ██████████░░░░░░  No:    51.1%
└─────────────────────────────────────────────────────┘
```

### Score Matrix
Top 20 most likely scores in a grid/table:
```
┌─────────────────────────────────────────────────┐
│              Most Likely Scores                 │
├─────────┬─────────┬─────────┬─────────┬─────────┤
│ 1-1: 11.2% │ 1-0: 9.8% │ 2-1: 8.5% │ 0-1: 7.9% │ 2-0: 7.2% │
│ 1-2: 6.8%  │ 0-0: 6.5% │ 2-2: 5.9% │ 3-1: 4.8% │ 0-2: 4.5% │
└─────────────────────────────────────────────────┘
```

### Team Stats Comparison
Two-column comparison with visual bars:
- Attack Strength
- Defense Strength
- Home Advantage (for home team)
- Recent Form
- Goal averages

### H2H History Section
- Previous meetings table
- Win/Draw/Loss record between teams
- Average goals in meetings
- BTTS percentage in meetings

### League Insights Panel
- League average goals
- Home win rate in league
- BTTS rate in league
- How this match compares to league averages

---

## Technical Requirements

### Dependencies
```json
{
  "dependencies": {
    "next": "^15.x",
    "react": "^18.x",
    "react-dom": "^18.x",
    "tailwindcss": "^3.x"
  }
}
```

### Data Fetching
- Use native `fetch()` API
- Handle CORS (football-data.co.uk allows direct access)
- Implement error handling for failed requests
- Parse CSV using string manipulation (no external CSV parser needed)

### CSV Parsing Logic
```javascript
function parseCSV(csvText) {
  const lines = csvText.split('\n');
  const headers = lines[0].split(',');
  
  return lines.slice(1)
    .filter(line => line.trim())
    .map(line => {
      const values = line.split(',');
      const obj = {};
      headers.forEach((h, i) => {
        obj[h.trim()] = values[i]?.trim() || '';
      });
      return obj;
    });
}
```

### Caching Implementation
```javascript
let cachedData = null;
let cacheTimestamp = 0;
const CACHE_DURATION = 10 * 60 * 1000; // 10 minutes

async function getSoccerData() {
  const now = Date.now();
  if (cachedData && (now - cacheTimestamp) < CACHE_DURATION) {
    return cachedData;
  }
  
  const data = await fetchAllLeagues();
  cachedData = data;
  cacheTimestamp = now;
  return data;
}
```

### Poisson Distribution Function
```javascript
function poisson(lambda, k) {
  return (Math.pow(lambda, k) * Math.exp(-lambda)) / factorial(k);
}

function factorial(n) {
  if (n <= 1) return 1;
  return n * factorial(n - 1);
}

function poissonRandom(lambda) {
  const L = Math.exp(-lambda);
  let k = 0;
  let p = 1;
  
  do {
    k++;
    p *= Math.random();
  } while (p > L);
  
  return k - 1;
}
```

---

## Error Handling

- Display user-friendly error messages
- Handle network failures gracefully
- Show loading states during data fetch
- Validate team selections before prediction
- Handle missing/insufficient historical data

---

## Loading States

- Skeleton loaders for tables
- Spinner for data fetching
- Progress indicator for prediction generation
- Disable controls during loading

---

## Responsive Design

- Mobile: Stack all elements vertically
- Tablet: 2-column layouts where appropriate
- Desktop: Full multi-column layouts
- Tables: Horizontal scroll on mobile

---

## Metadata (layout.tsx)

```typescript
export const metadata: Metadata = {
  title: 'Techmari Results Analyzer',
  description: 'Comprehensive soccer historical data analysis and Monte Carlo prediction engine',
  keywords: 'soccer, football, predictions, analysis, Monte Carlo, Poisson, statistics, betting',
  author: 'Techmari',
};
```

---

## Summary

Create a Next.js 15 application that:
1. Fetches and processes historical soccer data from football-data.co.uk (25 leagues, 8 seasons)
2. Provides league overview with team statistics and standings
3. Enables head-to-head comparison between any two teams
4. Implements Monte Carlo simulation (100,000 iterations) with Poisson distribution for match predictions
5. Calculates attack/defense strength, expected goals, and probabilities for multiple markets
6. Uses 10-minute caching for optimal performance
7. Has a professional dark-themed responsive UI with three tabs
8. Provides confidence levels, score matrices, and detailed team comparisons

The app should be fully functional, production-ready, and provide accurate predictions based on historical performance data.
